num = float(input('Unesite ceo broj: '));

if num == 0 :
    print('Broj je jednak nuli!');
elif num < 0 :
    print('Broj je negativan!');
else :
    print('Broj je pozitivan!');
