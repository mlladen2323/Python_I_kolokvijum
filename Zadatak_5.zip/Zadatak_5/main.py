num_elem = int(input("Unesi broj elemenata niza: ")) + 1;
print("Unesi broj");
niz = [0] * num_elem;


def unosUNiz(niz):
    for i in range(1, num_elem):
        # niz[i] = int(input("Broj " + str(i) + ":"));
        niz[i] = int(input("Unesite broj:"))
        # i++;

def kub(broj):
    return broj ** 3;


def ispisNiza(niz):
    for i in range(1, num_elem):
        niz[i] = kub(niz[i]);
        print(niz[i]);


unosUNiz(niz);
ispisNiza(niz);


