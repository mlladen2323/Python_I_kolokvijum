izbor = 0;
while True:
    print("\r\nIzaberi opciju:");
    print(" ");
    print("1) Racunaj obim i povrsinu kvadrata!");
    print("2) Racunaj obim i povrsinu pravougaonika");
    print("0) Izadji iz programa!");

    izbor = (int(input("Unesi broj: ")));

    if izbor == 1:
        print("Izabrao/la si kvadrat!");
        a = int(input("Unesi stranicu kvadrata a="));

        obim = 4 * a;
        povrsina = a * a;
        print("Obim kvadrata je: " + str(obim));
        print("Povrsina: " + str(povrsina));
    elif izbor == 2:
        print("Izabrao/la pravougaonik!");
        a = int(input("Unesi duzinu pravougaonika: "));
        b = int(input("\r\nUnesi sirinu pravougaonika: "));

        obim = 2 * a + 2 * b;
        povrsina = a * b;

        print("Obim pravougaonika je: " + str(obim));
        print("Povrsina pravougaonika je: " + str(povrsina));
    else :
        print("Goodbye!");
        exit();

