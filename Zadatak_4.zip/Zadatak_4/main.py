import math;
print('_____________________________________________________________________________________________');
print('Program za racunanje kvadratne jednacine');
print('\n oblika: ax^2+bx+c=0 ');

a=int(input('Uneti promenljivu a= '));
b=int(input('Uneti promenljivu b= '));
c=int(input('Uneti promenljivu c= '));
d1=b**2-4*a*c;


if d1 > 0:
    x1=(-b+math.sqrt(d1))/(2*a);
    x2=(-b-math.sqrt(d1))/(2*a);
    x1=round(x1,2);
    x2=round(x2,2);
    print("X1: ",x1);
    print("X2: ",x2);
elif d1 == 0:
    x1=(-b+math.sqrt(d1))/(2*a);
    x1=round(x1,2);
    print("Racunanje kvadratne jednacine: ",x1);
elif d1 < 0:
    d1=-1*d1;
    x1=-b/2*a;
    x2=math.sqrt(d1)/2*a;
    x1=round(x1,2);
    x2=round(x2,2);
    print("Racunanje kvadratne jednacine:=",x1,"+i",x2);
    print("Racunanje kvadratne jednacine:=",x1,"-i",x2);
