from turtle import Turtle

t = Turtle()
t.screen.bgcolor("black")


def square(length):
    for steps in range(4):
        t.fd(length)
        t.left(90)


def draw_square(x, y, length):
    t.hideturtle()
    t.up()
    t.goto(x, y)
    t.down()
    t.begin_fill()
    square(length)
    t.end_fill()


def rectangle(length, width):
    for steps in range(2):
        t.fd(width)
        t.left(90)
        t.fd(length)
        t.left(90)


def draw_ractangle(langth, width, x, y):
    t.hideturtle()
    t.up()
    t.goto(x, y)
    t.down()
    t.begin_fill()
    rectangle(length, width)
    t.end_fill()


t.color("Magenta")
t.write("Python kodiranje", move=True, align='center',
        font=('Arial', 20, 'normal'))
t.color("black")

draw_square(-160, 20, 20)

t.fd(40)
t.color("black")
t.fd(10)
t.left(90)
t.color("Magenta")
t.begin_fill()
t.fd(30)
t.left(90)
t.fd(60)
t.left(90)
t.fd(80)
t.left(90)
t.fd(60)
t.left(90)
t.fd(50)
t.end_fill()

t.color("black")
draw_square(-120, -20, 20)
draw_square(-120, 20, 20)
draw_square(-140, -20, 20)
draw_square(-140, 0, 20)
draw_square(-140, 20, 20)
